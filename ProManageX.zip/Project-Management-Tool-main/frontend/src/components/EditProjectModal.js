import React from 'react'

const EditProjectModal = () => {
    return (
        <div>EditProjectModal</div>
    )
}

export default EditProjectModal